export class Kitchen{
    Item:number;
    Name:string;
    Cost:number;
    Rating:number;
    qnt:number;
    Img:string;
}
export class Kitchens{
    constructor(public Item="", public Name="",public Cost="", public Rating="",public qnt="",public Img=""){

    }
}